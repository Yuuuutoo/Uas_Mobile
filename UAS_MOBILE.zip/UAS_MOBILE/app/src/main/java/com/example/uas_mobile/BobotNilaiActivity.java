package com.example.uas_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BobotNilaiActivity extends AppCompatActivity {

    EditText nKhdran, nuts, nuas, ntgs;
    Double hadir, tugas, uts, uas, nakhir;

    String grade;
    TextView takhir, ngrade;
    Button Btnext2;

    String nim, nama, matkul;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bobot_nilai);

        String kehadiran = getIntent().getExtras().getString("kehadiran");
        matkul = getIntent().getExtras().getString("matkul");
        tugas = Double.valueOf(getIntent().getExtras().getString("tugas"));
        uts = Double.valueOf(getIntent().getExtras().getString("uts"));
        uas = Double.valueOf(getIntent().getExtras().getString("uas"));
        nim = getIntent().getExtras().getString("nim");
        nama = getIntent().getExtras().getString("nama");

        nKhdran = findViewById(R.id.hadiran);
        nKhdran.setText(kehadiran);

        ntgs = findViewById(R.id.nTugas);
        ntgs.setText(tugas.toString());

        nuas = findViewById(R.id.nlUAS);
        nuas.setText(uas.toString());

        nuts = findViewById(R.id.nlUTS);
        nuts.setText(uts.toString());

        takhir = findViewById(R.id.takhir);
        ngrade = findViewById(R.id.tgrade);
        Btnext2 = findViewById(R.id.next2);

        Btnext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hadir= Double.parseDouble(nKhdran.getText().toString());
                tugas= Double.parseDouble(ntgs.getText().toString());
                uts= Double.parseDouble(nuts.getText().toString());
                uas= Double.parseDouble(nuas.getText().toString());

                nakhir = (hadir * 0.1) + (tugas * 0.3) + (uts * 0.3) + (uas * 0.3);

                if (nakhir >= 80) {
                    grade = "Nilai A";
                }else if (nakhir >= 65) {
                    grade = "Nilai B";
                }else if (nakhir >= 55) {
                    grade = "Nilai C";
                }else if (nakhir >= 40) {
                    grade = "Nilai D";
                }else {
                    grade = "Nilai F";
                }
                takhir.setText(""+nakhir);
                ngrade.setText(""+ngrade);

                Intent i = new Intent( BobotNilaiActivity.this, HasilActivity.class);
                i.putExtra("Akhir", takhir.getText().toString());
                i.putExtra("grade", ngrade.getText().toString());
                i.putExtra("nim", nim);
                i.putExtra("nama", nama);
                i.putExtra("matkul", matkul);
                startActivity(i);


            }
        });
    }
}